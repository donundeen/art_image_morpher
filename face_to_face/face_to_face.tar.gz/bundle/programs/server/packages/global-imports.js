/* Imports for global scope */

HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
gm = Package['cfs:graphicsmagick'].gm;
Counts = Package['tmeasday:publish-counts'].Counts;
publishCount = Package['tmeasday:publish-counts'].publishCount;
Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Log = Package.logging.Log;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
Iron = Package['iron:core'].Iron;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Autoupdate = Package.autoupdate.Autoupdate;
HTML = Package.htmljs.HTML;

